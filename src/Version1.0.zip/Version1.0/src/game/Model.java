package game;

import game.Panel;

public class Model {
	private Panel panel;
	private int n;
	private int x;
	private int y;
	private static int[][] gameGrid;
	
	//Constructor
	public Model(Panel view){
		this.panel = view;
		this.n = panel.getN();
		this.x = n-1;
		this.y = this.x;
		
		//Creates and array of ints whih will hold the numbers for the game
		gameGrid = new int[n][n];
	}
	
	//Method which "shuffels" the game so the first row will start with 2,3,1
	//and then the rest of the numbers will be sortet from 4 til n-1
	public void startShuffle(){
		int temp = 1;
		for(int i = 0; i<n;i++){
			for(int j = 0;j<n;j++){
				gameGrid[i][j] = temp;
				
				temp++;
			}
		}
		gameGrid[n-1][n-1] = 0;
		gameGrid[0][0] = 2;
		gameGrid[0][1] = 3;
		gameGrid[0][2] = 1;
		panel.updatePanel();
	}
	
	//Method which check wether you have won the game. 
	public boolean checkWinCondition(){
		int tempx=0;
		int tempy=0;
		for(int i = 1;i<n*n;i++){
			if(tempx==n-1){
				if(gameGrid[tempy][tempx]!= i){
					return false;
				}
				tempx=0;
				tempy++;
			}
			else{
				if(gameGrid[tempy][tempx]!= i){
					return false;
				}
				tempx++;
			}
		}
		return true;
	}

	//updates/swaps the numbers in the gameGrid array
	public void updateArray(int y, int x, int movey, int movex){
		int temp = gameGrid[y][x];
		gameGrid[y][x] = gameGrid[movey][movex];
		gameGrid[movey][movex] = temp;
		this.y=movey;
		this.x=movex;
	}
	
	//Method for controlling the movement of the white tile compared to which arrowkey is pressed
	public void movement(int c){
		
		switch(c){
	case 38:
		if (!(y>n-2)){
			updateArray(y, x, y+1, x);
			if(y==n-1 && x==n-1 && gameGrid[n-1][n-2]==n*n-1){
				if(checkWinCondition())
					panel.youWon();
			}
		}
		break;
	
	case 40:
		if (!(y<1)){
			updateArray(y, x, y-1, x);
		}
		break;
		
	case 37:
		if (!(x>n-2)){
			updateArray(y, x, y, x+1);
			
			if(y==n-1 && x==n-1 && gameGrid[n-1][n-2]==(n*n-1)){
				if(checkWinCondition())
					panel.youWon();
			}
		}
		break;
		
	case 39:
		if (!(x<1)){
			updateArray(y, x, y, x-1);}
		break;
		}
		panel.updatePanel();
	}	
	
	//Methods to get certain values in other classes
	public int[][] PuzzleArray(){
		return gameGrid;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
}
