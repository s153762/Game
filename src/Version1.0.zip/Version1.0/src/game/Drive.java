package game;

import java.util.InputMismatchException;
import java.util.Scanner;

import game.Frame;

public class Drive {
	
	public static void main(String[] args){
		int n = getInput();
		//Creates a frame
		Frame f = new Frame(n);
		f.showIt();

	}
	//Gets and input from the user and chekcs if it's legal
	public static int getInput(){
		int n = 0;
		Scanner scanner = new Scanner(System.in);
		try{
			while (!(n<=100 && n>=3)){
				System.out.println("Enter the size of your game(Between 3-100): ");
				n = scanner.nextInt();
			}
		} catch(InputMismatchException ime){
			System.out.println("The size has to be a number integer!");
			n = getInput();
		}
		scanner.close();
		return n;
	}

}
