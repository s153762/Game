package game;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

//Panel which extends the JPanel
public class Panel extends JPanel {
	private Model model;
	private int n;
	private Listener list;
	private boolean firstTime;
	private JLabel[][] puzzleArray;
	
	//constructor
	public Panel(int n){
		//Initialize n, crates new model, creates new JabelArray, sets gridLayout and set the background color
		this.n = n;
		this.model = new Model(this);
		this.puzzleArray = new JLabel[n][n];
		this.firstTime = true;
		this.setLayout(new GridLayout(n,n));
		this.setBackground(Color.white);
		
		//Creates a listener and adds it to the panel
		list = new Listener(this.model);
		this.addKeyListener(list);
		
		//Calls the shuffle method from the model
		model.startShuffle();
		
	}
	
	//Changes the fontSize of the numbers in the grid
	public Float FontSize(){
		double fontSize = Frame.size/(n*3);
		return (float) fontSize; 
	}
	
	//If the method is run for the first time it creates the label, else it updates the text on the labels
	public void updatePanel(){
		for(int i = 0; i<n;i++){
			for(int j = 0;j<n;j++){
				if(firstTime){
					if(model.PuzzleArray()[i][j] != 0){
						puzzleArray[i][j] = new JLabel(""+model.PuzzleArray()[i][j]);
						this.add(puzzleArray[i][j]);
						puzzleArray[i][j].setHorizontalAlignment(JLabel.CENTER);
						puzzleArray[i][j].setFont (getFont ().deriveFont (FontSize()));
						puzzleArray[i][j].setBorder(new LineBorder(Color.BLACK));
					} else{
						puzzleArray[i][j] = new JLabel("");
						this.add(puzzleArray[i][j]);
						puzzleArray[i][j].setHorizontalAlignment(JLabel.CENTER);
						puzzleArray[i][j].setFont (getFont ().deriveFont (FontSize()));
						puzzleArray[i][j].setBorder(new LineBorder(Color.BLACK));		
					}
				} else{
					if(model.PuzzleArray()[i][j] != 0){
						puzzleArray[i][j].setText(""+model.PuzzleArray()[i][j]);
					} else{
						puzzleArray[i][j].setText("");		
					}
				} 
			}	
			
		}
		firstTime = false;
		}
		
	//Creates a MessageDialog which says the user won, then it shut down the program
	public void youWon(){
		updatePanel();
		this.removeKeyListener(list);
		JOptionPane.showMessageDialog(null, "Congratulation! You won the game!");
		System.exit(0);
		
		
	}
	
	//Return the n value
	public int getN() {
		return n;
	}
	
}
