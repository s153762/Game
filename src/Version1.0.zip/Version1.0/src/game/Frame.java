package game;

import javax.swing.JFrame;

import game.Panel;

//Frame wich extends JFrame
public class Frame extends JFrame {

	private int n;
	private Panel panel;
	public static double size = 600;
	
	//constructor
	public Frame(int n){
		//assigns the n value with the userinput from the driveclass
		this.n = n;
		
		//Sets title, layout, size, position & closeOperation of the frame
		this.setSize((int) (size*1.25),(int) size);
		this.setLocation(100,50);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle(n*n-1+"-Puzzle");
		
		//Creates a panel and adds it to the frame & makes it focusable
		this.panel = new Panel(this.n);
		this.getContentPane().add(panel);
		panel.setFocusable(true);
		
	}
	
	//shows the frame
	public void showIt(){
		this.setVisible(true);
	}
	
	//hides the frame
	public void hideIt() { 
		this.setVisible(false);
	}


}
