package game;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

//Listener class which implements Key Listener
public class Listener implements KeyListener{
	private Model model;

	//Constructor which initializes the model
	public Listener(Model model){
		this.model = model;
	}
	//Check which botton is pressed and passes the movement to model.movement()
	public void keyPressed(KeyEvent e){
		int c = e.getKeyCode();
		model.movement(c);
	}
	//not used
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
	}
	//not used
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
	}

}
